flask_microservices_gui_orders_fixed - run with docker-compose up --build
